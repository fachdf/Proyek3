## Daftar Isi

- [Seeders](#seeders)

## Seeders
Jika ingin generate data dummy menggunakan seeder jalankan command dibawah ini
``` cmd
$ npx sequelize-cli db:seed:all
```
CATATAN : Pastikan anda telah menjalankan file migrasi terlebih dahulu menggunakan command
``` sh
$ npx sequelize-cli db:migrate
```
