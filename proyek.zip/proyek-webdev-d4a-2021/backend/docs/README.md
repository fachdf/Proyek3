### Practical Documentation

In this folder there will be Thunder Client Collection file. To use it,

1. Install thunder client in [VS Code extensions](https://marketplace.visualstudio.com/items?itemName=rangav.vscode-thunder-client)
2. Import the `thunder-collection...` file in this folder to thunder client, by doing

   1. Go to thunder client tab in vs code
   2. Click on the Collections tab
   3. Click on the button besides the `filter collections` input
   4. Click import, and import the respective file
