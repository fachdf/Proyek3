import { initKeycloak } from '../config/keycloak-config'
const keycloak = initKeycloak()

export default keycloak
