export const AKUN_API_URL = process.env.VUE_APP_AKUN_API_URL
export const AKUN_BASE_URL = process.env.VUE_APP_AKUN_BASE_URL

export const ABSENSI_API_URL = process.env.VUE_APP_ABSENSI_API_URL
export const ABSENSI_BASE_URL = process.env.VUE_APP_ABSENSI_BASE_URL

export const MONITORING_API_URL = process.env.VUE_APP_MONITORING_API_URL
export const MONITORING_BASE_URL = process.env.VUE_APP_MONITORING_BASE_URL

export const PENILAIAN_API_URL = process.env.VUE_APP_PENILAIAN_API_URL
export const PENILAIAN_BASE_URL = process.env.VUE_APP_PENILAIAN_BASE_URL

export const NOTIFICATION_BASE_URL = process.env.VUE_APP_NOTIFICATION_BASE_URL
