<template>
  <v-dialog max-width="600px">
    <v-card
      height="100%"
    >
    <form class="mt-10">
    </form>
    </v-card>
   </v-dialog>
</template>

<script>
export default {
  props: {
    onDialogClosed: Function
  }
}
</script>
