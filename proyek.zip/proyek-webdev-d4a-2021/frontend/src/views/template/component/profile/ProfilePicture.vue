<template>
    <v-avatar size="200">
        <img
        src="https://i.pinimg.com/564x/98/95/20/98952030526063f8050c817aa9a9d566.jpg"
      >
    </v-avatar>
</template>

<script>
export default {
  name: "ProfilePicture"
}
</script>
